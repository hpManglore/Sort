package com.example.vikrant.sort;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button b1;
    EditText e1;
    String num[];
    TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1 = (Button) findViewById(R.id.button);
        e1 = (EditText) findViewById(R.id.editText);
        tv = (TextView) findViewById(R.id.textView);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                num = e1.getText().toString().split(" ");


                for (int i = 0; i < num.length; i++) {
                    for (int j = 0; j < num.length - i - 1; j++) {
                        if (Float.parseFloat(num[j]) > Float.parseFloat(num[j + 1])) {
                            String temp;
                            temp = num[j];
                            num[j] = num[j + 1];
                            num[j + 1] = temp;
                        }
                    }

                }
                String res = " ";
                for (int i = 0; i < num.length; i++)
                {
                    res+= num[i] + "\n";

                }
                tv.setText(res);
            }
        });
    }
}