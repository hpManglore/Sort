package com.example.dellc4.sorting;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView txt;
    Button b;
    EditText e1;
    String num[];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b=(Button)findViewById(R.id.button2);
        e1=(EditText)findViewById(R.id.editText);
        txt=(TextView)findViewById(R.id.textView);

       b.setOnClickListener(new OnClickListener()        {
            @Override
            public void onClick(View v) {

               num=e1.getText().toString().split(",");
                for(int i=0;i<num.length;i++)
               {
                   for(int j=0;j<num.length-i-1;j++)
                   {
                       if(Float.parseFloat(num[j])>Float.parseFloat(num[j+1]))
                       {
                           String temp;
                           temp=num[j];
                           num[j]=num[j+1];
                           num[j+1]=temp;

                       }

                   }
               }
               String res = " ";
               for(int i=0;i<num.length;i++)
               {
                   res+=num[i]+"\n";
               }
               txt.setText(res);
            }


        });


    }
}
